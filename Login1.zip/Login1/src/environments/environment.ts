
export const environment = {
  production: false,
  firebaseConfig:{
    apiKey: "AIzaSyCrk0GoBXApW414_sLS1fN3Kx-l1QUzVPU",
    authDomain: "login-b203c.firebaseapp.com",
    projectId: "login-b203c",
    storageBucket: "login-b203c.appspot.com",
    messagingSenderId: "976058218502",
    appId: "1:976058218502:web:5797d68b0737801ce1eb87",
    measurementId: "G-E81BPF3RWR"
  }
};
