export enum Role
{
    Admin='Admin',
    Employee='Employee'
}