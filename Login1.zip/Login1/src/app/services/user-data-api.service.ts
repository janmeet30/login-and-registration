import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';
import {AngularFirestore,AngularFirestoreCollection} from '@angular/fire/firestore';

import { Observable } from 'rxjs';
import {map} from 'rxjs/operators';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})

export class UserDataApiService {


  private usersList:AngularFireList<any>;

  constructor(private afs:AngularFirestore, private firebase: AngularFireDatabase) {
    this.dataUserCollection=afs.collection<User>('userdata2');

    this.dataUser=this.dataUserCollection.valueChanges();

    this.usersList= this.firebase.list('users');
   }

  //Declared Variables to Use using the Userinterface to assign the parameters
  private dataUserCollection: AngularFirestoreCollection<User>;
  private dataUser: Observable<User[]>;

  //Simple Method to get All the data from the DB on Firebase
  getAllDatUser(){
    return this.dataUser=this.dataUserCollection.snapshotChanges()
    .pipe(map(changes =>{
     return changes.map(action =>{
       const data = action.payload.doc.data() as User;
       return data;
     }) 
    }))
  }
//Simple Method to Add Data to Data Base
  addDataUser(dataUser:User):void{
    //Use the method add from AngularFirestoreCollection to add data
    this.dataUserCollection.add(dataUser);
  }
  
  getUsersFromFirebase()
  {
    return this.usersList;
  }

  addUserToFirebase(user: IUser)
  {
    this.usersList.push(user);
  }
  
}
